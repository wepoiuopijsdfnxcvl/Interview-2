package com.atuigu.crm.repository;

import com.atuigu.crm.entity.Role;

public interface RoleRepository extends BaseRepository<Role>{

}
