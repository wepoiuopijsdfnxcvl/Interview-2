package com.atuigu.crm.repository;

import com.atuigu.crm.entity.SalesPlan;
 
public interface SalesPlanRepository extends BaseRepository<SalesPlan>{

}
