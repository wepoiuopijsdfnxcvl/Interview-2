package com.atuigu.crm.repository;

import com.atuigu.crm.entity.Authority;

public interface AuthorityRepository extends BaseRepository<Authority>{

}
