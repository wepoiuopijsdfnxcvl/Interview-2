package com.atuigu.crm.repository;

import com.atuigu.crm.entity.CustomerService;

public interface CustomerServiceRepository extends BaseRepository<CustomerService>{

}
