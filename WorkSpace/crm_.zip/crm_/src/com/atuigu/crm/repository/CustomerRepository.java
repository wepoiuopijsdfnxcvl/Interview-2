package com.atuigu.crm.repository;

import com.atuigu.crm.entity.Customer;

public interface CustomerRepository extends BaseRepository<Customer>{
	
}
