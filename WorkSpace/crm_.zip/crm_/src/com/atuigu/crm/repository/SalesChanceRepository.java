package com.atuigu.crm.repository;

import com.atuigu.crm.entity.SalesChance;


public interface SalesChanceRepository extends BaseRepository<SalesChance>{

}
