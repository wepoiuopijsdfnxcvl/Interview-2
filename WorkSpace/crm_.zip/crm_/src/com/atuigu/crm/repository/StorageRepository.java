package com.atuigu.crm.repository;

import com.atuigu.crm.entity.Storage;

public interface StorageRepository extends BaseRepository<Storage>{

}
