package com.atuigu.crm.repository;

import com.atuigu.crm.entity.Order;

public interface OrderRepository extends BaseRepository<Order>{
	
}
