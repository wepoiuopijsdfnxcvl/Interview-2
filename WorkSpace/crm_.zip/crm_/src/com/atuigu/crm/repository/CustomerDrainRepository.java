package com.atuigu.crm.repository;


import com.atuigu.crm.entity.CustomerDrain;

public interface CustomerDrainRepository extends BaseRepository<CustomerDrain>{
	
	
}
