package com.atuigu.crm.repository;

import com.atuigu.crm.entity.CustomerActivity;

public interface CustomerActivityRepository extends BaseRepository<CustomerActivity>{

}
