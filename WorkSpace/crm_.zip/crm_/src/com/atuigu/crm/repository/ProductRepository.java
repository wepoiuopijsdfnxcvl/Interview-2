package com.atuigu.crm.repository;

import com.atuigu.crm.entity.Product;

public interface ProductRepository extends BaseRepository<Product>{

}
