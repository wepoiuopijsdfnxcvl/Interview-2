package com.atuigu.crm.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.atuigu.crm.entity.SalesPlan;

@Service
@Transactional
public class SalesPlanService extends BaseService<SalesPlan>{

}
