package com.atuigu.crm.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.atuigu.crm.entity.Role;

@Service
@Transactional
public class RoleService extends BaseService<Role>{

}
