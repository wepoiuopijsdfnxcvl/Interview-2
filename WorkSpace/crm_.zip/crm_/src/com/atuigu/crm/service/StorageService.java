package com.atuigu.crm.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.atuigu.crm.entity.Storage;

@Transactional
@Service
public class StorageService extends BaseService<Storage>{

	
}
