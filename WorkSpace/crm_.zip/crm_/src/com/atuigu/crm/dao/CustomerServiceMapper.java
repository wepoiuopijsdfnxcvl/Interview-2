package com.atuigu.crm.dao;

public interface CustomerServiceMapper {

}
